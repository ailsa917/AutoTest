package com.xinghai.pachong;

import java.io.*;
import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;

public class B extends A {
    private int age;
//    public B() {
//        System.out.println("子类的无参构造");
//    }

//    public B(String name, String ssex,int age) {
//    super(name,ssex);
//        System.out.println("子类的有参构造器");
//        System.out.println("子类说深入段修文的子宫");
//    }

    @Override
    public void fmethod() {
        System.out.println("子类的方法");
    }
} class C{

    public static void main(String[] args) {

        A b=new B();
        b.fmethod();

        System.out.println();


    }




}

  class D{

      public static void main(String[] args) throws UnknownHostException {
          InetAddress byName = InetAddress.getByName("localhost");
          System.out.println(byName);
      }
  }


