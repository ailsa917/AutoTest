package com.xinghai.test;

import org.testng.annotations.*;

public class BfTest {
    @BeforeMethod
    public void bf (){
        System.out.println("方法执行前");
    };
    @AfterMethod
    public void af (){
        System.out.println("方法执行后");
    };
}
