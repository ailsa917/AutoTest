package com.xinghai.test;

import org.testng.annotations.*;

public class TestPay {

    @BeforeTest
    public void bf (){
        System.out.println("1的用例执行前");
    };
    @AfterTest
    public void af (){
        System.out.println("1的用例执行后");
    };
    @Test
    public void paytestcase1(){
        System.out.println("支付测试1");
        System.out.println("我当前所在的线程是"+Thread.currentThread().getId());
    }

    @Test
    public void paytestcase2(){
        System.out.println("支付测试2");
        System.out.println("我当前所在的线程是"+Thread.currentThread().getId());
    }

//    @Test(timeOut = 1000)
//    public void paytestcase3() throws InterruptedException {
//        System.out.println("支付测试3");
//        System.out.println("我当前所在的线程是"+Thread.currentThread().getId());
//        Thread.sleep(100);
//    }
}
