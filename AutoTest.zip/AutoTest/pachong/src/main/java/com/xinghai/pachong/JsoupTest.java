package com.xinghai.pachong;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.junit.Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class JsoupTest {

    @Test
    public void test1 () throws IOException {

        URL url = new URL("https://www.98qaweq423aeqstudio.xyz/forum.php?mod=viewthread&tid=419155&extra=page%3D1%26filter%3Dtypeid%26typeid%3D654");
        Document doc = Jsoup.parse(url, 1000);
        String title = doc.getElementsByTag("title").first().text();
        System.out.println();
//        System.out.println(title);
    };


}
