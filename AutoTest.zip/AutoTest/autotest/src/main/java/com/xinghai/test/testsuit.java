package com.xinghai.test;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class testsuit {
    @BeforeSuite
    public void beforesuit(){
        System.out.println("测试套件运行了");
    }
    @AfterSuite
    public void aftersuit(){
        System.out.println("测试套件结束了");

    }
}
