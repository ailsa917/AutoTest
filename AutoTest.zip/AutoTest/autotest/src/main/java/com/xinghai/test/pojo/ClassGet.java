package com.xinghai.test.pojo;

import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

public class ClassGet {
    public static void main(String[] args) {

        String url = GetValueByProperties("url");
        System.out.println(url);

    }

    public static String GetValueByProperties(String KeyStr) {

        String result ="";
        try {
            InputStream in = ClassGet.class.getResourceAsStream("/config.properties");
            BufferedReader bf = new BufferedReader(new InputStreamReader(in));//据说这一句使用来读取中文用的
            Properties p = new Properties();
            p.load(in);
            result = p.getProperty(KeyStr);
        } catch (Exception ex) {
        }

        return result;
    }



   @Test
   public void get1() {
       System.out.println("第一种：获取类加载的根路径" + this.getClass().getResource("/").getPath());

    }

}


//
//    @Test
//    public void get2() {
//        System.out.println("第一种：获取类加载的工程路径" + this.getClass().getResource("").getPath());
//
//    }
// @Test

