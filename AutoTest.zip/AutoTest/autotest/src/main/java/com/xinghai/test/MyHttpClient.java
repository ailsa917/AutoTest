package com.xinghai.test;

import com.xinghai.test.pojo.ClassGet;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import javax.swing.text.html.parser.Entity;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

public class MyHttpClient {

    private String get_url;
    private String cookie_url;
    private String json_url;
    private DefaultHttpClient client;
    @BeforeTest
    public void bf (){
        get_url= ClassGet.GetValueByProperties("get-url");
         cookie_url=ClassGet.GetValueByProperties("cookie-url");
        json_url=ClassGet.GetValueByProperties("json-url");
         client =new DefaultHttpClient() ;
    };

    @Test
    public void http () throws IOException {
        String result;
        HttpGet get = new HttpGet(get_url);



        HttpResponse response =client.execute(get);
        result = EntityUtils.toString(response.getEntity());
        CookieStore cookieStore = client.getCookieStore();
        List<Cookie> cookies = cookieStore.getCookies();
        for (Cookie cookie :cookies){
            System.out.println("cookie的值是"+cookie.getName()+"="+cookie.getValue());

        }
        System.out.println(result);
    };
    @Test(dependsOnMethods = "http")
     public void cookierequest () throws IOException {
         HttpGet get = new HttpGet(cookie_url);
         CookieStore cookieStore = client.getCookieStore();
         client.setCookieStore(cookieStore);
         HttpResponse response =client.execute(get);
         int statusCode = response.getStatusLine().getStatusCode();
         System.out.println("响应码是"+statusCode);
        System.out.println( EntityUtils.toString(response.getEntity()));


     };
    @Test
    public void jsonpost () throws IOException {
        HttpPost post = new HttpPost(json_url);
        System.out.println(json_url);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name","duanxiuwen");
        jsonObject.put("sex","women");
        post.setHeader("content-type","application/json");
        StringEntity stringEntity = new StringEntity(jsonObject.toString(),"utf-8");
        post.setEntity(stringEntity);
        CookieStore cookieStore = client.getCookieStore();
        client.setCookieStore(cookieStore);
        HttpResponse response =client.execute(post);

        int statusCode = response.getStatusLine().getStatusCode();
        System.out.println("响应码是"+statusCode);
//        System.out.println( EntityUtils.toString(response.getEntity()));
        JSONObject jsonObject1 = new JSONObject(EntityUtils.toString(response.getEntity()));

         String name=(String) jsonObject1.get("name");
        System.out.println(name);
        Assert.assertEquals("段修文",name);


    };
}
