package com.xinghai.test.pojo;

public class Women {
    private String name;

    public Women() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    private String sex;
    public String getName() {
        return name;
    }

    public String getSex() {
        return sex;
    }

    public Women(String name, String sex) {

        this.name = name;
        this.sex = sex;
    }



    public void hobby() {
        System.out.println("我叫" + name + "/n" + "我的性别是" + sex);

    }

    ;


}
