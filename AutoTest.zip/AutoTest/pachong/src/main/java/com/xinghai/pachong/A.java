package com.xinghai.pachong;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Date;

public class A {
    private String name;
    private String ssex;

  public A() {
       System.out.println("父类的无参构造器");
  }

    public A(String name, String ssex) throws FileNotFoundException {
        this.name = name;
        this.ssex = ssex;
        System.out.println("父类的有参构造器");
        PrintStream ps = new PrintStream("你好");
        ps.print("hahah");

    }
    public void fmethod (){
        System.out.println("父类的方法");
    };
}
