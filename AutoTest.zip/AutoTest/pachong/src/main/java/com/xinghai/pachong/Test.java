package com.xinghai.pachong;

import com.alibaba.fastjson.JSON;


import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONPObject;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xinghai.pachong.domain.Person;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Date;
import java.util.List;



public class Test {
    public static void main(String[] args) {

        String duanxiuwen = "{\"name\":\"段修文\",\"sex\":\"女\",\"age\":\"28\"}";
        String jsonStr = "{\"request\":\"success\",\"age\":18,\"school\":\"清华大学\"}";
        String jsonString ="{\"name\":\"zhangsan\",\"password\":\"zhangsan123\",\"email\":\"10371443@qq.com\"}";
        JSONObject json = JSON.parseObject(duanxiuwen);
        String name = json.getString("name");
        System.out.println(name);
        Person person = JSON.parseObject(duanxiuwen, Person.class);


    }
}
