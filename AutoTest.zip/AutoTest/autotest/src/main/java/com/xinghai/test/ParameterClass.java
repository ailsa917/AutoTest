package com.xinghai.test;

import com.xinghai.test.pojo.Women;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

public class ParameterClass {
    @Test
    @Parameters({"name", "age"})
    public void parameter(String name, String age) {
        System.out.println("参数用例执行了");
        System.out.println("我的名字是" + name + "\n" + "我的年龄是" + age);
    }

    @Test(dataProvider = "wm")
    public void duanxiuwen(String name, String sex) {
        System.out.println("我的名字是" + name + "我的性别是" + sex);
    }

    @Test(dataProvider = "wm")
    public void gaoyuanyuan(String name, String sex) {
        System.out.println("我的名字是" + name + "我的性别是" + sex);
    }

    @DataProvider(name = "wm")
    public Object[][] parameterprovide(Method method) {
         Object[][] ob=null;
        if (method.getName().equals("duanxiuwen")) {
            Object[][] objects = {{"段修文", "女"}};
           ob=objects;
        }



        if (method.getName().equals("gaoyuanyuan")) {
            Object[][] objects = {{"高圆圆", "女"}};
            ob=objects;
        }


        return ob;
    }
}
