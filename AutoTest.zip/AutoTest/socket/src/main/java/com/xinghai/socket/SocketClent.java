package com.xinghai.socket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class SocketClent {
    public static void main(String[] args) throws IOException {

        Socket cliensocket = new Socket("localhost", 9999);
        OutputStream outputStream = cliensocket.getOutputStream();
        outputStream.write("你好".getBytes());
        InputStream inputStream = cliensocket.getInputStream();
        byte[] buffer = new byte[1024];

        inputStream.read(buffer);
        System.out.println(new String(buffer));
        inputStream.close();
        outputStream.close();
        cliensocket.close();

    }
}
