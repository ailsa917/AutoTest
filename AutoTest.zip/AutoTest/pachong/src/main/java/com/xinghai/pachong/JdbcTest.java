package com.xinghai.pachong;

import java.sql.*;

public class JdbcTest {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");

        String url =new String("jdbc:mysql://localhost:3306/zxh?useUnicode=true&characterEncoding=utf8&useSSL=true");
        String usename="root";
        String password="root";
        String sql="select * from test";
        Connection connection = DriverManager.getConnection(url, usename, password);
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()){
            System.out.println(resultSet.getObject("name"));
        }
        resultSet.close();
        statement.close();
        connection.close();

    }


}
