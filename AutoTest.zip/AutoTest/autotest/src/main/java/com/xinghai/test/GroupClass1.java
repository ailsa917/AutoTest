package com.xinghai.test;

import org.testng.annotations.Test;

@Test(groups = "A")
public class GroupClass1 {
    public void mothd1(){
        System.out.println("我在a组");
    }
}
