package com.xinghai.pachong;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;

import java.io.IOException;

public class HttpClientPool {
    public static void main(String[] args) {

        PoolingHttpClientConnectionManager pool = new PoolingHttpClientConnectionManager();

  httpPool(pool);
    }

    public static void httpPool (PoolingHttpClientConnectionManager pm){
        CloseableHttpClient build = HttpClients.custom().setConnectionManager(pm).build();
        HttpGet httpGet = new HttpGet("https://www.98qaweq423aeqstudio.xyz/forum.php?mod=forumdisplay&fid=36&filter=typeid&typeid=654");
        RequestConfig config = RequestConfig.custom().setConnectionRequestTimeout(1000)
                .setConnectTimeout(1000)
                .setSocketTimeout(1000).build();
        httpGet.setConfig(config);
        CloseableHttpResponse result1=null;
        try {
            result1 = build.execute(httpGet);
            String s = EntityUtils.toString(result1.getEntity(), "utf-8");
            System.out.println(s);
            System.out.println("hahahah");

        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {

            try {
                if (result1!=null)
                    result1.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    };
}
