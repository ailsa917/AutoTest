package com.xinghai.test;

import org.junit.After;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

@Test(groups = "A")
public class TestLogin {
    @Test
@Parameters("sex")
    public void testcas1(String sex) {
        System.out.println("我的性别是"+sex);
        System.out.println("我当前所在的线程是"+Thread.currentThread().getId());

    }

    @Test
    public void testcase2() {
        System.out.println("测试用例2执行了");
        System.out.println("我当前所在的线程是"+Thread.currentThread().getId());
        //System.out.println("我要抛异常了");
        //throw new RuntimeException();

    }
    @Test(dependsOnMethods = {"testcase2"})
    public void testcase9() {
        System.out.println("测试用例3执行了");

    }
    @Test(enabled = false)
    public void testcase3() {
        System.out.println("测试用例3被执行了");
    }

    @Test(groups = "jj")
    public void testcase4() {
        System.out.println("我是a小组1号");
    }

    @Test(groups = "jj")
    public void testcase5() {
        System.out.println("我是a小组2号");
    }

    @BeforeGroups(groups = "jj")
    public void testcase6() {
        System.out.println("我在小组之前运行");
    }

    @AfterGroups(groups = "jj")
    public void testcase7() {
        System.out.println("我在小组之后运行");
    }

    @Test(expectedExceptions = RuntimeException.class)
    public void testcase8() {
        System.out.println("这是我异常测试");
        throw new RuntimeException();

        // System.out.println("这是一个异常的测试");
    }
}
