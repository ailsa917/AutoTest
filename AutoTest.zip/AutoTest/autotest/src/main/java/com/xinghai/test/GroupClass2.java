package com.xinghai.test;

import org.testng.annotations.Test;

@Test(groups = "B")
public class GroupClass2 {
    public void methd2(){
        System.out.println("我在B组");
    }
}
