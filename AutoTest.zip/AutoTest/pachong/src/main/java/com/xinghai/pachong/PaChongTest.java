package com.xinghai.pachong;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class PaChongTest {
    public static void main(String[] args) throws Exception {

        PoolingHttpClientConnectionManager pool = new PoolingHttpClientConnectionManager();
        CloseableHttpClient httpclient = HttpClients.createDefault();
        URIBuilder uriBuilder = new URIBuilder("https://www.98qaweq423aeqstudio.xyz/forum.php");
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("mod", "forumdisplay"));
        nameValuePairs.add(new BasicNameValuePair("fid", "36"));
        nameValuePairs.add(new BasicNameValuePair("filter", "typeid"));
        nameValuePairs.add(new BasicNameValuePair("typeid", "654"));
        // 这是get方式的提交参数的方式
        uriBuilder.setParameters(nameValuePairs);
//        HttpGet httpGet = new HttpGet(uriBuilder.build());
        HttpPost httpPost = new HttpPost(uriBuilder.build());
        System.out.println("发起请求的信息：" + httpPost);
        CloseableHttpResponse execute = httpclient.execute(httpPost);
        String statucode = execute.getStatusLine().getReasonPhrase();
        String result = EntityUtils.toString(execute.getEntity());
        System.out.println("状态码是：" + statucode + "\n" + "返回的内容是" + result);


    }

    @org.junit.Test
    public void dopost() throws IOException {

        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost("https://www.98qaweq423aeqstudio.xyz/forum.php");
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("mod", "forumdisplay"));
        nameValuePairs.add(new BasicNameValuePair("fid", "36"));
        nameValuePairs.add(new BasicNameValuePair("filter", "typeid"));
        nameValuePairs.add(new BasicNameValuePair("typeid", "654"));
        // 这是表单方式的请求体
        UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(nameValuePairs, "utf-8");
//        HttpGet httpGet = new HttpGet(uriBuilder.build());
        httpPost.setEntity(urlEncodedFormEntity);
        System.out.println("发起请求的信息：" + httpPost);
        CloseableHttpResponse execute = httpclient.execute(httpPost);
        String statucode = execute.getStatusLine().getReasonPhrase();
        String result = EntityUtils.toString(execute.getEntity());
        System.out.println("状态码是：" + statucode + "\n" + "返回的内容是" + result);

    }
   @org.junit.Test
    public void httpPool (PoolingHttpClientConnectionManager pm){
        CloseableHttpClient build = HttpClients.custom().setConnectionManager(pm).build();
        HttpGet httpGet = new HttpGet("https://www.98qaweq423aeqstudio.xyz/forum.php?mod=forumdisplay&fid=36&filter=typeid&typeid=654");
        CloseableHttpResponse result=null;
        try {
             result = build.execute(httpGet);
            String s = EntityUtils.toString(result.getEntity(), "utf-8");
            System.out.println(s);

        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {

            try {
                if (result!=null)
                result.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    };
}
