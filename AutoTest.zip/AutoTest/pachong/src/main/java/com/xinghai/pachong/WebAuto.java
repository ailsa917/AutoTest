package com.xinghai.pachong;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebAuto {

    @Test
    public void webat() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:\\Program Files (x86)\\Google\\Chrome\\Application\\chromedriver.exe");
        WebDriver drive = new ChromeDriver();
        WebDriver.Window window = drive.manage().window();
        window.maximize();
        drive.get("htp://www.baidu.com");
        Thread.sleep(2000);
        drive.navigate().back();



        drive.get("https://www.98qaweq423aeqstudio.xyz/forum.php?mod=viewthread&tid=419155&extra=page%3D1%26filter%3Dtypeid%26typeid%3D654");
      drive.quit();

    }






}

