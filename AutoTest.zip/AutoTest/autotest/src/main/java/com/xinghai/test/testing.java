package com.xinghai.test;

import org.testng.annotations.*;

public class testing {
    @Test
    public void testcase1(){
        System.out.println("这是我的第一个测试用例");
        System.out.println("我的对象地址是"+this);
    }
    @Test
    public void testcase2(){
        System.out.println("这是我的第二个测试用例");
        System.out.println("我的对象地址是"+this);
    }

    @BeforeMethod
    public void beforemethod(){

        System.out.println("方法执行之前");
//        System.out.println("我的对象地址是"+this);
    }
    @AfterMethod
    public void afterremethod(){

        System.out.println("方法执行之后");
    }
    @BeforeTest
    public void beforetest(){

        System.out.println("用例执行之前");
////        System.out.println("我的对象地址是"+this);
   }
    @AfterTest
    public void aftertest(){

        System.out.println("用例执行之后");
    }
    @BeforeSuite
    public void beforesuite(){
        System.out.println("测试套件执行了");
    }
    @AfterSuite
    public void aftersuite(){
        System.out.println("测试套件结束了");
    }
//    @BeforeClass
//    public void beforeclass(){
//        System.out.println("类执行前");
//    }
//    @AfterClass
//    public void aftereclass(){
//        System.out.println("类执行后");
//    }
}
