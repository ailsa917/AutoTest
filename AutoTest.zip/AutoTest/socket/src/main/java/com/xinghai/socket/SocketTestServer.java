package com.xinghai.socket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketTestServer {
    public static void main(String[] args) throws IOException {

        int port=9999;
        ServerSocket serversocket = new ServerSocket(port);
        Socket accept = serversocket.accept();
        InputStream is = accept.getInputStream();
        int length;
        byte[] buffer =new byte[1024];
        is.read(buffer);
        System.out.println(new String(buffer));
        OutputStream os = accept.getOutputStream();
        os.write("收到".getBytes());
        os.close();
        is.close();
        accept.close();

    }



}
